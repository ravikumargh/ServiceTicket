'use strict';

/**
 * @ngdoc function
 * @name sample2App.controller:AboutCtrl
 * @description
 * # AboutCtrl
 * Controller of the sample2App
 */
angular.module('sample2App')
  .controller('AboutCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
